INSERT INTO DEFECT_TRACKER ( description , category , priority , status , changed_status)  values 
  ('Customer can not add value to cart','Functional', 'Simple', 'Open','Open'),
  ('Page load incorrectly for customer in US region ','UI', 'Medium', 'Closed','Closed') ; 