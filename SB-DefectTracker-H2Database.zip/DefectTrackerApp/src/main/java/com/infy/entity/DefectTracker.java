package com.infy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DEFECT_TRACKER")
public class DefectTracker {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="defect_id")
        private long defectid;  
	
	@Column(name="description")
        private String description;
	
	@Column(name="category")
    private String category;

	@Column(name="priority")
    private String priority;

	@Column(name="status")
    private String status;

	@Column(name="changed_status")
    private String changedstatus;

	public long getDefectid() {
		return defectid;
	}

	public void setDefectid(long defectid) {
		this.defectid = defectid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getChangedstatus() {
		return changedstatus;
	}

	public void setChangedstatus(String changedstatus) {
		this.changedstatus = changedstatus;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
