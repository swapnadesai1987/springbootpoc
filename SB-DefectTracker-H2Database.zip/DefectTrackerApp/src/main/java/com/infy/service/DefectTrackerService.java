package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.DefectTracker;
import com.infy.exception.ResourceNotFoundException;
import com.infy.repository.DefectTrackerRepository;

@Service
public class DefectTrackerService implements IDefectTrackerService{

	@Autowired
	private DefectTrackerRepository defectTrackerRepos;

	@Override
	public List<DefectTracker> getAllDefects() {
		System.out.println(">>>>>Inside Method getAllDefects()");
		List<DefectTracker> list = new ArrayList<>();
		defectTrackerRepos.findAll().forEach(e -> list.add(e));
		return list;
	}

	@Override
	public DefectTracker getDefectById(long defectid) {
		System.out.println(">>>>>Inside Method getDefectById()");
		DefectTracker obj = defectTrackerRepos.findById(defectid).get();
		return obj;
	}

	@Override
	public boolean addDefect(DefectTracker defect) {
		System.out.println(">>>>>Inside Method addDefect()");
			defectTrackerRepos.save(defect);
			return true;
	}
	

	@Override
	public void updateDefect(DefectTracker defect) {
		System.out.println(">>>>>Inside Method updateDefect()");		
		
		DefectTracker d = defectTrackerRepos.findById(defect.getDefectid())
	            .orElseThrow(() -> new ResourceNotFoundException("Defect", "id", defect.getDefectid()));

		d.setCategory(defect.getCategory());
		d.setChangedstatus(defect.getChangedstatus());
		d.setDescription(defect.getDescription());
		d.setStatus(defect.getStatus());
		d.setPriority(defect.getPriority());
				
	    defectTrackerRepos.save(d);
	}

	@Override
	public void deleteDefect(long defectid) {
		System.out.println(">>>>>Inside Method deleteDefect()");
		defectTrackerRepos.delete(getDefectById(defectid));
	}
	
	
	
	
}
