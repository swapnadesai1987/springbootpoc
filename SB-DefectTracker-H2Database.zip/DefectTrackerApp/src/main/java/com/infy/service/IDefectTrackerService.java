package com.infy.service;

import java.util.List;

import com.infy.entity.DefectTracker;

public interface IDefectTrackerService {
  
	List<DefectTracker> getAllDefects();
	DefectTracker getDefectById(long defectid);
    boolean addDefect(DefectTracker defect);
    void updateDefect(DefectTracker defect);
    void deleteDefect(long defectid);
 	
}
