package com.infy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.util.UriComponentsBuilder;

import com.infy.entity.DefectTracker;
import com.infy.service.IDefectTrackerService;


@Controller
public class DefectTrackerController {

	@Autowired
	private IDefectTrackerService defectTrackerService;
	
	@GetMapping("defects")
	public ResponseEntity<List<DefectTracker>> getAllDefects() {
		List<DefectTracker> list = defectTrackerService.getAllDefects();
		return new ResponseEntity<List<DefectTracker>>(list, HttpStatus.OK);
	}
	
	@GetMapping("defects/{defectid}")
	public ResponseEntity<DefectTracker> getDefectById(@PathVariable("defectid") long defectid) {
		DefectTracker defect = defectTrackerService.getDefectById(defectid);
		return new ResponseEntity<DefectTracker>(defect, HttpStatus.OK);
	}
	
	@PostMapping("defect")
	public ResponseEntity<Void> addDefect(@RequestBody DefectTracker defect, UriComponentsBuilder builder) {
		defectTrackerService.addDefect(defect);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/defects/{defectid}").buildAndExpand(defect.getDefectid()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@PutMapping("defect")
	public ResponseEntity<DefectTracker> updateDefect(@RequestBody DefectTracker defect) {
		defectTrackerService.updateDefect(defect);
		return new ResponseEntity<DefectTracker>(defect, HttpStatus.OK);
	}
	
	@DeleteMapping("defects/{defectid}")
	public ResponseEntity<Void> deleteStudent(@PathVariable("defectid") long defectid) {
		defectTrackerService.deleteDefect(defectid);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
}
