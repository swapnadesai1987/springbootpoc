package com.infy.repository;

import org.springframework.data.repository.CrudRepository;
import com.infy.entity.*;

public interface DefectTrackerRepository  extends CrudRepository<DefectTracker, Long>{

}
