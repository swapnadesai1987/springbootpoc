package com.infy;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefectTrackerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
